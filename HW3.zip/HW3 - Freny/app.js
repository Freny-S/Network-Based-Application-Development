var express = require('express');

var app = express();

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

var bodyParser = require('body-parser');
var session = require('express-session');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:false }));
app.use(session({secret: 'freny_session'}));

var controller = require('./controller/controller');
var ProfileController = require('./controller/ProfileController');

app.use('/', ProfileController);
app.use('/', controller);

app.listen(8080);
