var express = require('express');
var router = express.Router();
var itemDb = require('../utility/itemDB');
var bodyParser = require('body-parser');
var session = require('express-session');
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended:false }));
router.use(session({secret: 'freny_session'}));

var the_user = {};

router.use(function getSession(req, res, next){
    console.log("*********************************" + req.session.theUser);
    if(req.session.theUser){
        the_user = req.session.theUser;
        user = new User(the_user._userId, the_user._firstName, the_user._lastName, the_user._email);
        var the_user_profile = req.session.userProfile;
        userProfile = new UserProfile(the_user_profile._userId);
        for(var i=0; i < the_user_profile._userItemList.length; i++){
            var userItem = new UserItem(the_user_profile._userItemList[i]._itemCode,
            the_user_profile._userItemList[i]._itemName,
            the_user_profile._userItemList[i]._catalogCategory,
            the_user_profile._userItemList[i]._rating,
            the_user_profile._userItemList[i]._readIt);
            userProfile.addItem(userItem);
        }
        ////console.log(userProfile);
    }
    else{
        the_user = {};
        userProfile = null;
    }
    next();
});

router.get('/', function(req, res, next) {
    var data= {
        title:'Home',
        path: req.url,
        user: the_user
    };
    //console.log('user : ',data.user);
    res.render('index', {data: data});
});

router.get('/categories', function(req, res, next) {
    var categories = getCategories();
    var itemData = itemDb.getItems();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData,
        user: the_user
    }
    //console.log(itemData);
    res.render('categories',{ data: data});
});

router.get('/categories/:categoryName', function (req,res) {
    // get the category name
    var categories = [];
    categories.push(req.params.categoryName);
    var itemData = itemDb.getItems();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData
    }
    res.render('categories',{ data: data});
});

router.get('/contact', function(req, res, next) {
    var data= {
        title:'Contact Us',
        path: req.url,
        user: the_user
    }

    res.render('contact', { data: data});
});
router.get('/about', function(req, res, next) {
    var data= {
        title:'About Us',
        path: req.url,
        user: the_user
    }

    res.render('about', { data: data});
});
router.get('/categories/item/:itemCode', function(req, res, next) {
    var present = itemDb.isExist(req.params.itemCode);
    if(present){
      var itemCode = req.params.itemCode;
      //console.log("Item Code:"+itemCode);
      var item = itemDb.getItem(itemCode);
      //console.log(item);
      var data= {
          title:'Item',
          path: req.url,
          item: item,
          user: the_user
      }
      res.render('item', { data: data});
    }
    else{
      res.redirect('/categories');
    }

});


router.get('/myBooks', function(req, res, next) {
    var data= {
        title:'My Books',
        path: req.url,
        user: user,
        userProfile: userProfile
    }
    //console.log(userProfile);
    res.render('myBooks', { data: data});
});

router.get('/categories/item/:itemCode/feedback', function(req, res, next) {
    var itemCode = req.params.itemCode;
    var item = itemDb.getItem(itemCode);
    var itemData = itemDb.getItems();
    var item_feedback = {};
    for(var i = 0; i < itemData.length; i++){
      if(itemData[i]._itemCode == itemCode){
        item_feedback = itemData[i];
      }
    }
    var data= {
        title:'My Books',
        path: req.url,
        items: item_feedback,
        user: the_user,
        userProfile: userProfile
    }
    res.render('feedback', { data: data});
});


var categories = [];
let getCategories = function() {
    // get the category of each item
    var data = itemDb.getItems();
    data.forEach(function (item) {
        if(!categories.includes(item.catalogCategory)){
            categories.push(item.catalogCategory);
        }

    });
    return categories;
};

router.get('/feedback', function(req, res, next) {
    var page= {
        title:'Feedback',
        path: req.url
    }
    res.render('feedback', { title:page});
});

router.get('/*',function(req, res, next) {
    var data= {
        title:'Error',
        user: the_user,
        path: req.url
    };
    res.render('error', { data: data});
});

module.exports = router;
