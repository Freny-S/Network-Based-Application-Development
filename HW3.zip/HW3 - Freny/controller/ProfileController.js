var express = require('express');
var router = express.Router();
var userDB = require('../utility/UserDB');
var itemDb = require('../utility/ItemDB');
var bodyParser = require('body-parser');
var session = require('express-session');
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended:false }));
router.use(session({secret: 'freny_session'}));

router.get('/signin', function(req, res, next){
    //console.log("Hey");
    if(req.session.theUser){
        //console.log('Already logged in');
        res.redirect('/myBooks');
    }
    else{
        //console.log("signin");
        users = userDB.getUsers();
        var user = users[Math.floor(Math.random() * users.length)];
        req.session.theUser = user;
        req.session.userProfile = userDB.getUserProfile(user.userId);
        res.redirect('/myBooks');
    }
});

router.get('/signout', function(req, res, next){
    if(req.session.theUser){
        req.session.theUser = null;
        res.redirect('/');
    }
});

router.get('/categories/item/saveIt/:itemCode', function(req, res, next){
    if(req.session.theUser){
      //console.log("yo");
      var itemCode = req.params.itemCode;
      //console.log("Item Code:"+itemCode);
      var item = itemDb.getItem(itemCode);
      var userItem = new UserItem(item.itemCode, item.itemName, item.catalogCategory, 0, false);
        req.session.userProfile._userItemList.push(userItem);
        //console.log('userProfile - save : ',req.session.userProfile._userItemList);
        res.redirect('/myBooks');
    }
    else{
        res.redirect('/categories/item/' + req.params.itemCode);
    }
});

router.post('/update/feedback/:itemCode', function(req, res){
    var temp=-1;
    if(req.session.theUser){
        temp = getSelectedItem(req.session.userProfile._userItemList, req.params.itemCode);
        if(temp==-2){
            res.redirect('/myItems');
        }else{
            if(req.body.feedbackHidden=='rating'){
                req.session.userProfile._userItemList[temp]._rating = parseInt(req.body.rating,10);
                res.redirect('/myBooks');
            }else if(req.body.feedbackHidden=='readIt'){
                req.session.userProfile._userItemList[temp]._madeIt = JSON.parse(req.body.readItRadio);
                res.redirect('/myBooks');
            }else{
                res.redirect('/categories/item/'+req.params.itemCode+'/feedback');
            }
        }
    }else{
        res.redirect('/categories/item/'+req.params.itemCode+'/feedback');
    }
});

function getSelectedItem(itemList, itemCode){
    for (var index = 0; index < itemList.length; index++) {
        //console.log(itemList[index]._itemCode);
        //console.log(itemList[index]._itemCode == parseInt(itemCode,10));
        if(itemList[index]._itemCode == parseInt(itemCode,10)){
            return index;
        }
    }
    return -2;
}

router.get('/myBooks/delete/:itemCode', function(req, res){
    var index = -1;
    if(req.session.theUser){
        index = getSelectedItem(req.session.userProfile._userItemList, req.params.itemCode);
        if(index==-2){
            //console.log('Item not present in the user profile');
            res.redirect('/myBooks');
        }else{
            req.session.userProfile._userItemList.splice(index, 1);
            res.redirect('/myBooks');
        }
    }else{
        res.redirect('/myBooks');
    }
});

module.exports = router;
