var User = require('../models/User');
var UserItem = require('../models/UserItem');
var Item = require('../models/Item');
var UserProfile = require('../models/UserProfile');

var userData = [
    {
        userId: 1,
        firstName: "Freny",
        lastName: "Savalia",
        email: "fsavalia@uncc.edu"

    }
];

var userProfileData = [
    {
        userId: 1,
        userItemList: [
            {
                itemCode: 1,
                itemName: "An Unwanted Guest",
                catalogCategory: "Thriller",
                rating: 5,
                readIt: true
            },
            {
                itemCode: 3,
                itemName: "Give Me Your Hand",
                catalogCategory: "Thriller",
                rating: 3,
                readIt: true
            },
            {
                itemCode: 5,
                itemName: "Macbeth",
                catalogCategory: "Drama",
                rating: 4,
                readIt: false
            }
        ]
    }
];

module.exports.getUsers = function(){

    var users = [];
    for (var i = 0; i < userData.length; i++) {
      var user = new User(
        userData[i].userId,
        userData[i].firstName,
        userData[i].lastName,
        userData[i].email
      );
      users.push(user);
    }
    return users;

};

module.exports.getUserProfiles = function(){

    var userProfiles = [];
    for (var i = 0; i < userProfileData.length; i++){
      var userProfile = new UserProfile(userProfileData[i].userId);
      for(var j=0; j < userProfileData[i].userItemList.length; j++){
        var userItem = new UserItem(
          userProfileData[i].userItemList[j].itemCode,
          userProfileData[i].userItemList[j].itemName,
          userProfileData[i].userItemList[j].catalogCategory,
          userProfileData[i].userItemList[j].rating,
          userProfileData[i].userItemList[j].readIt
        );
        userProfile.addItem(userItem);
      }
      userProfiles.push(userProfile);
    }
    return userProfiles;
};

module.exports.getUser = function(userId){

  for (var i = 0; i < userData.length; i++){
    if (parseInt(userData[i].userId) == userId){
      var user = new User(
        userData[i].userId,
        userData[i].firstName,
        userData[i].lastName,
        userData[i].email
      );
      return user;
    }
  }
};

module.exports.getUserProfile = function(userId){

    for (var i = 0; i < userProfileData.length; i++){
      if (parseInt(userProfileData[i].userId) == userId){
        var userProfile = new UserProfile(userProfileData[i].userId);
        for(var j=0; j < userProfileData[i].userItemList.length; j++){
          var userItem = new UserItem(
            userProfileData[i].userItemList[j].itemCode,
            userProfileData[i].userItemList[j].itemName,
            userProfileData[i].userItemList[j].catalogCategory,
            userProfileData[i].userItemList[j].rating,
            userProfileData[i].userItemList[j].readIt
          );
          userProfile.addItem(userItem);
        }
        return userProfile;
      }
    }
};
