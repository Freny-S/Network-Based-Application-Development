var Item = require('../models/Item');

var data = [
  {
      itemCode: 1,
      itemName: "An Unwanted Guest",
      catalogCategory: "Thriller",
      descriptionTitle: ["Thriller Books"],
      description: ["It’s winter in the Catskills and Mitchell’s Inn, nestled deep in the woods, is the perfect setting for a relaxing — maybe even romantic — weekend away. It boasts spacious old rooms with huge woodburning fireplaces, a well-stocked wine cellar, and opportunities for cross-country skiing, snowshoeing, or just curling up with a good murder mystery. So when the weather takes a turn for the worse, and a blizzard cuts off the electricity –and all contact with the outside world — the guests settle in for the long haul. Soon, though, one of the guests turns up dead — it looks like an accident. But when a second guest dies, they start to panic. Within the snowed-in paradise, something — or someone — is picking off the guests one by one. And there’s nothing they can do but hunker down and hope they can survive the storm."],
      rating: 5,
      imageURL: "/assets/images/an_unwanted_guest.jpg",
  },
  {
    itemCode: 2,
    itemName: "Bring Me Back",
    catalogCategory: "Thriller",
    descriptionTitle: ["Thriller Books"],
    description: ["Finn and Layla are young, in love, and on vacation. They’re driving along the highway when Finn decides to stop at a service station to use the restroom. He hops out of the car, locks the doors behind him, and goes inside. When he returns Layla is gone--never to be seen again. That is the story Finn told to the police. But it is not the whole story."],
    rating: 3,
    imageURL: "/assets/images/bring_me_back.jpg"
  },
  {
    itemCode: 3,
    itemName: "Give Me Your Hand",
    catalogCategory: "Thriller",
    descriptionTitle: ["Thriller Books"],
    description: ["You told each other everything. Then she told you too much. Kit has risen to the top of her profession and is on the brink of achieving everything she wanted. She hasn’t let anything stop her. But now someone else is standing in her way - Diane. Best friends at seventeen, their shared ambition made them inseparable. Until the day Diane told Kit her secret - the worst thing she’d ever done, the worst thing Kit could imagine - and it blew their friendship apart. Kit is still the only person who knows what Diane did. And now Diane knows something about Kit that could destroy everything she’s worked so hard for."],
    rating: 4,
    imageURL: "/assets/images/give_me_your_hand.jpg"
  },
  {
      itemCode: 4,
      itemName: "Romeo And Juliet",
      catalogCategory: "Drama",
      descriptionTitle: ["Drama Books"],
      description: ["It’s winter in the Catskills and Mitchell’s Inn, nestled deep in the woods, is the perfect setting for a relaxing — maybe even romantic — weekend away. It boasts spacious old rooms with huge woodburning fireplaces, a well-stocked wine cellar, and opportunities for cross-country skiing, snowshoeing, or just curling up with a good murder mystery. So when the weather takes a turn for the worse, and a blizzard cuts off the electricity –and all contact with the outside world — the guests settle in for the long haul. Soon, though, one of the guests turns up dead — it looks like an accident. But when a second guest dies, they start to panic. Within the snowed-in paradise, something — or someone — is picking off the guests one by one. And there’s nothing they can do but hunker down and hope they can survive the storm."],
      rating: 5,
      imageURL: "/assets/images/romeo_and_juliet.jpg",
  },
  {
      itemCode: 5,
      itemName: "Macbeth",
      catalogCategory: "Drama",
      descriptionTitle: ["Drama Books"],
      description: ["It’s winter in the Catskills and Mitchell’s Inn, nestled deep in the woods, is the perfect setting for a relaxing — maybe even romantic — weekend away. It boasts spacious old rooms with huge woodburning fireplaces, a well-stocked wine cellar, and opportunities for cross-country skiing, snowshoeing, or just curling up with a good murder mystery. So when the weather takes a turn for the worse, and a blizzard cuts off the electricity –and all contact with the outside world — the guests settle in for the long haul. Soon, though, one of the guests turns up dead — it looks like an accident. But when a second guest dies, they start to panic. Within the snowed-in paradise, something — or someone — is picking off the guests one by one. And there’s nothing they can do but hunker down and hope they can survive the storm."],
      rating: 4,
      imageURL: "/assets/images/macbeth.jpg",
  },
  {
      itemCode: 6,
      itemName: "Othello",
      catalogCategory: "Drama",
      descriptionTitle: ["Drama Books"],
      description: ["It’s winter in the Catskills and Mitchell’s Inn, nestled deep in the woods, is the perfect setting for a relaxing — maybe even romantic — weekend away. It boasts spacious old rooms with huge woodburning fireplaces, a well-stocked wine cellar, and opportunities for cross-country skiing, snowshoeing, or just curling up with a good murder mystery. So when the weather takes a turn for the worse, and a blizzard cuts off the electricity –and all contact with the outside world — the guests settle in for the long haul. Soon, though, one of the guests turns up dead — it looks like an accident. But when a second guest dies, they start to panic. Within the snowed-in paradise, something — or someone — is picking off the guests one by one. And there’s nothing they can do but hunker down and hope they can survive the storm."],
      rating: 4,
      imageURL: "/assets/images/othello.jpg",
  }
];

module.exports.getItems = function () {

  var itemsCategory = [];
  for (var i = 0; i < data.length; i++) {
      var item = new Item(data[i].itemCode,
          data[i].itemName,
          data[i].catalogCategory,
          data[i].descriptionTitle,
          data[i].description,
          data[i].rating,
          data[i].imageURL);

      itemsCategory.push(item);

  }// end of for
  return itemsCategory;

  // return data;
};


module.exports.getItem = function (itemCode) {
    console.info("from DB, Item code :" + itemCode);
    for (var i = 0; i < data.length; i++) {
        // var itemCode = data.itemCode;
        console.log("Data" + JSON.stringify(data[i].imageURL));
        if (parseInt(data[i].itemCode) == itemCode) {
            console.log("Inside if");
            var item = new Item(data[i].itemCode,
                data[i].itemName,
                data[i].catalogCategory,
                data[i].descriptionTitle,
                data[i].description,
                data[i].rating,
                data[i].imageURL);

            console.log("Item"+JSON.stringify(item));

            return item;
        }
        // console.log("Data"+i);

    }
};

var categories = ['Thriller','Drama','Biography'];

module.exports.getCategories = function(){
    return categories;
};

module.exports.isExist = function(itemCode){
    var present = false;
    for (var i = 0; i < data.length; i++){
      if (parseInt(data[i].itemCode) == itemCode){
        present = true;
      }
    }
    return present;
}
