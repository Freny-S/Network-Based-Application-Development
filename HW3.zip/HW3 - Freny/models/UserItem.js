class UserItem {

    /**
     * Constructor
     * @param itemCode
     * @param itemName
     * @param catalogCategory
     * @param rating
     * @param madeIt
     */
    constructor(itemCode, itemName, catalogCategory, rating, readIt) {
        this._itemCode = itemCode;
        this._itemName = itemName;
        this._catalogCategory = catalogCategory;
        this._rating = rating;
        this._readIt = readIt;
    }

    /**
     *
     * Getter and Setters
     */

    get itemCode() {
        return this._itemCode;
    }

    set itemCode(value){
        this._itemCode = value;
    }

    get itemName() {
        return this._itemName;
    }

    set itemName(value){
        this._itemName = value;
    }

    get catalogCategory() {
        return this._catalogCategory;
    }

    set catalogCategory(value){
        this._catalogCategory = value;
    }

    get rating(){
        return this._rating;
    }

    set rating(value){
        this._rating = value;
    }

    get readIt(){
        return this._readIt;
    }

    set readIt(value){
        this._readIt = value;
    }

}
module.exports = UserItem;
