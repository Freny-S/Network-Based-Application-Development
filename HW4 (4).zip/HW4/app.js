var express = require('express');
var app = express();
//var router = express.Router();
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/bookbarn',{ useNewUrlParser: true })
  .then(() =>  console.log('connection succesful'))
  .catch((err) => console.error(err));

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

var bodyParser = require('body-parser');
var session = require('express-session');
var cookieParser = require('cookie-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:false }));
app.use(session({
  secret: 'freny_session',
  resave: true,
  saveUninitialized: true
}));

var controller = require('./controller/controller');
var profilecontroller = require('./controller/ProfileController');

//app.use('/', profilecontroller.router);
app.use('/', controller);
 // app.use('/', profilecontroller.router);
/*
app.use('/categories',controller);
app.use('/about',controller);
app.use('/contactUs',controller);
app.use('/categories/item/:id',controller);
app.use('/*',controller);
*/
app.listen('8080', function(req, res){
  console.log("Server started. Listening on port 8080");
});
