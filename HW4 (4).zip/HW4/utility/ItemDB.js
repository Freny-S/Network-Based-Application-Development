var Item = require('../models/item');

var itemDB = {};

itemDB.getItems = function () {
    return new Promise((resolve, reject) =>{
        Item.find({}).then(function(items) {
            resolve(items);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

itemDB.getItem = function (itemCode) {
    return new Promise((resolve, reject) =>{
        Item.findOne({itemCode: itemCode}).then(function(item) {
          console.log("-----------------" +item);
            resolve(item);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

var categories = ['Thriller', 'Drama', 'Biography'];
itemDB.getCategories = function(){
    return categories;
};

itemDB.isExist = function(itemCode){
    return new Promise((resolve, reject) =>{
        Item.find({itemCode: itemCode}).then(function(items) {
            if(items.length>0)
                resolve(true);
            else
                resolve(false);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

module.exports = itemDB;

/*
var itemSchema = mongoose.Schema({
  itemCode:{type:String, required:true, unique:true},
  itemName:{type:String},
  catalogCategory:{type:String},
  descriptionTitle:{type:String},
  description:{type:String},
  rating:{type:String},
  imageURL:{type:String}
});

var item = mongoose.model('itemDB', itemSchema);


module.exports.getItems = async function(){
  return await item.find();
};

module.exports.getItem = async function(itemCode){
  return await item.find({'itemCode': itemCode});
}

// var categories = ['Thriller','Drama','Biography'];

module.exports.getCategories = async function(){
  var categories = [];
  await item.find(function(err, data){
    if(err){
      throw err;
    }
    else{
      data.forEach(function(item){
        if(!categories.includes(item.catalogCategory)){
          categories.push(item.catalogCategory);
        }
      });
    }
  })
    return categories;
};



/* module.exports.isExist = function(itemCode){
    var present = false;
    for (var i = 0; i < data.length; i++){
      if (parseInt(data[i].itemCode) == itemCode){
        present = true;
      }
    }
    return present;
}
*/
