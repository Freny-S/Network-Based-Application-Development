var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var session = require('express-session');
var itemDb = require('../utility/ItemDB.js');
var User = require('../utility/UserDB.js');
var UserItem = require('../models/UserItem.js');
var UserProfile = require('../models/UserProfile.js');
var profilecontroller = require('./ProfileController');

//router.use(profileController);
router.use(bodyParser.json());

router.use(bodyParser.urlencoded({extended: false}));

var user = null;
var userProfile = null;
router.use(function getSession(req,res,next){
    if(req.session.theUser){
        user = req.session.theUser;
        userProfile = req.session.userProfile;
    }else{
        user = null;
        userProfile = null;
    }
    next();
});

router.all('/', function(req, res){
    var data = {
        title: 'Index',
        path: req.url,
        user: user
    };
    res.render('index',{data: data});
});

router.get('/categories',async function(req, res) {
    var itemData = await itemDb.getItems();
    var categories =await  itemDb.getCategories();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData,
        user: user
    };

    res.render('categories',{data: data});
});

router.get('/contact', function(req, res) {
    var data= {
        title:'Contact',
        path: req.url,
        user: user
    };
    res.render('contact',{data: data});
});

router.get('/about', function(req, res) {
    var data= {
        title:'About',
        path: req.url,
        user: user
    };
    res.render('about',{data: data});
});
router.get('/signin',async function(req, res){
    if(req.session.theUser){
        res.redirect('/myBooks');
    }else{
        var users =await  User.getUsers();
        var user = users[Math.floor(Math.random()*users.length)];
        req.session.theUser = user;
        req.session.userProfile = await User.getUserProfile(user.userId);
        //console.log("----------------------------$$$$$$$44 " + req.session.theUser);
        res.redirect('/myBooks');
    }
});

router.get('/signout', function(req, res){
    if(req.session.theUser){
        req.session.theUser = null;
        res.redirect('/');
    }
});

router.get('/myBooks',async function(req, res) {
  //console.log("----------------------------" + req.session.theUser);
  var userProfile = await User.getUserProfile(req.session.theUser.userId);
//console.log("----------------------------" + userProfile);
    if (req.session.theUser) {
        var data = {
            title: 'myBooks',
            path: req.url,
            user: user,
            userProfile: userProfile
        };
        res.render('myBooks', {
            data: data
        });
    } else {
        var users = await User.getUsers();
        var user1 = users[Math.floor(Math.random() * users.length)];
        req.session.theUser = user1;
       // req.session.userProfile = userDB.getUserProfile(user1.userId);
        res.redirect('/myBooks');
    }
});

router.get('/categories/item/:itemCode',async function(req, res) {

        var itemData = await itemDb.getItem(req.params.itemCode);
      //  //console.log("********************************" + itemData.imageURL);
        var index = -1;
        if(req.session.userProfile){
            index = profilecontroller.getSelectedItem(req.session.userProfile.userItemList, req.params.itemCode);
        }
        var data= {
            title:'Item',
            path: req.url,
            item: itemData,
            user: user,
            userProfile: userProfile,
            index: index
        };
        res.render('item',{data: data});

});

router.post('/update/feedback/:itemCode',async function (req, res) {
  var itemCode = req.params.itemCode;
  if (req.session.theUser) {
  //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$" + req.body.rating);
  var userProfile = await User.addItemRating(itemCode, req.session.theUser.userId, parseInt(req.body.rating));
   req.session.userProfile = userProfile;
   res.redirect('/myBooks');
 }
});


router.post('/update/readIt/:itemCode',async function (req, res) {
  var itemCode = req.params.itemCode;
  if (req.session.theUser) {
  //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$" + req.body.rating);
  var userProfile = await User.addReadIt(itemCode, req.session.theUser.userId,true);
   req.session.userProfile = userProfile;
   res.redirect('/myBooks');
 }
});

router.get('/categories/item/feedback/:itemCode',async function(req, res) {
  if (req.session.theUser){
    console.log("IN CONSOLE");
    var itemData = await itemDb.getItem(req.params.itemCode);
    var data= {
        title:'Feedback',
        path: req.url,
        item: itemData,
        user: user
    };
    res.render('feedback',{data: data});
  }
});
router.get('/myBooks/delete/:itemCode',async function(req, res){
    if(req.session.theUser){
            var userProfile = await User.deleteUserItem(req.params.itemCode,req.session.theUser.userId);
            req.session.userProfile = userProfile;
            res.redirect('/myBooks');

    }else{
        res.redirect('/');
    }
});

router.get('/*',function(req,res){
    var data= {
        title:'Error',
        path: req.url
    };
    //console.log('404')
    res.render('error',{data: data});
});

var getSelectedItem = function (itemList, itemCode) {
    for (var index = 0; index < itemList.length; index++) {
        if (itemList[index].itemCode == parseInt(itemCode, 10)) {
            return index;
        }
    }
    return -2;
};

module.exports = router;
