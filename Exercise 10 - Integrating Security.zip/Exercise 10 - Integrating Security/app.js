/* @nanajjar */

//setup express to use for routing
var express = require('express');
var app = express();
var expressValidator = require('express-validator');
app.use(expressValidator());
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Students',{ useNewUrlParser: true });
var TodoSchema = mongoose.Schema;

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
  console.log("Database Connected Successfully!");
});

var schemaOptions = {
    timestamps: true,
    toJSON: {
      virtuals: true
    }
};

var studentSchema = new TodoSchema({
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  },
  degree: String,
  program: String,
  graduationyear: String,
  email: String
}, schemaOptions);

var Student = mongoose.model('Student', studentSchema);


app.set('view engine', 'ejs');

app.use('/resources', express.static('resources'));

var studentInfo = require('./controls/studentInfo.js');
var index = require('./controls/index.js');
var bodyParser = require('body-parser');
var session = require('express-session');

var urlencodedParser = bodyParser.urlencoded({ extended:false });

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended:false }));

app.use(session({secret: 'session'}));

app.use('/', index);

app.use('/studentInfo',studentInfo);

var counter = 0;

app.post('/studentInfo', function(req,res,next){
  req.check('firstName').isAlpha().withMessage('First Name must be only alphabetical chars').isLength({
    min: 3
  }).withMessage('First Name must be at least 3 chars long');
  req.check('lastName').isAlpha().withMessage('Last Name must be only alphabetical chars').isLength({
    min: 3
  }).withMessage('Last Name must be at least 3 chars long');
  req.check('degree').isAlpha().withMessage('Degree must be only alphabetical chars');
  req.check('program').isAlpha().withMessage('Program must be only alphabetical chars');
  req.check('graduationyear').isNumeric().withMessage('Graduation Year must be numeric value');
  req.check('email').isEmail().withMessage('Please enter valid Email');

  var errors = req.validationErrors();
  ////console.log(req.body);
  var theStudent = require('./models/student');
  /*if(req.body.firstName=='' || req.body.lastName=='' || req.body.degree=='' || req.body.program==''){
    res.redirect('/');
  }*/
  theStudent.setFirstName(req.body.firstName);
  theStudent.setLastName(req.body.lastName);
  theStudent.setDegree(req.body.degree);
  theStudent.setProgram(req.body.program);
  theStudent.setGraduationyear(req.body.graduationyear);
  theStudent.setEmail(req.body.email);
  var student = theStudent.getStudentInfo();
  //console.log("*******************"+JSON.stringify(theStudent.getStudentInfo()));
  //console.log("$$$$$$$$$$$$$$$$$"+JSON.stringify(student));

  if(errors){
    res.render('index',{errors:errors[0].msg});
  }
  else{
    if(db.readyState==1){
      Student.findOneAndUpdate({firstName:req.body.firstName,lastName: req.body.lastName}, student, {upsert: true}, function(error, result) {
        if(error){
          console.log("Something went wrong, try again!");
          return handleError(error);
        }
        ////console.log(result);
        console.log('Data Saved!');
        req.session.theStudent = theStudent.getStudentInfo();
        if(req.session.theStudent){
          student = req.session.theStudent;
          res.render('main', { student: student });
        }else{
          res.redirect('/');
        }
      });
    }else{
      console.log('Unable to establish connection, try again!');
    }
  }


});

app.get('/display',function(req,res){
  console.log(mongoose.connection.readyState);
  if(db.readyState==1){
    Student.find(function (err, students) {
      if (err) return console.error(err);
      //console.log(students);
      res.render('display',{students:students});
    });
  }else{
    console.log('Unable to establish connection, try again!');
  }
});

app.post('/search', function(req,res){
  var firstName = req.body.firstName;
  if(db.readyState==1){
    Student.find({firstName: firstName},function(err, students){
      if (err) return console.error(err);
      //console.log(students);
      res.render('display',{students:students});
    });
  }else{
    console.log('Unable to establish connection, try again!');
  }
});

app.listen(8080, '127.0.0.1');
