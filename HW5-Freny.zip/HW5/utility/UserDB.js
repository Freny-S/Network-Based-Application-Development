var mongoose = require("mongoose");
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');

var userDB = {};

userDB.getUsers = function () {
    return new Promise((resolve, reject) =>{
        User.find({}).then(function(users) {
            resolve(users);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

userDB.getUser =  function (username, password){
    return new Promise((resolve, reject) =>{
        User.findOne({
          $and: [{
      username: username
    }, {
      password: password
    }]
  }, {
    userId: 1,
    firstName: 1,
    lastName: 1,
    email: 1,
    username: 1
        }).then(function(user) {
            resolve(user);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

userDB.getUserProfile = function (userId) {
    return new Promise((resolve, reject) =>{
        UserProfile.findOne({userId: userId}).then(function(userProfile) {
            resolve(userProfile);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

userDB.addUserItem = function(userId,userItem){
    return new Promise((resolve, reject) =>{
        UserProfile.findOneAndUpdate({userId: userId}, {$push: {userItemList: userItem}}, {new: true}).then(function(userProfile) {
            userProfile.save();
            resolve(userProfile);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

userDB.addItemRating = function (itemCode, userId, rating){
  console.log("*********************" + rating + itemCode + userId);
  return new Promise((resolve, reject) =>{
        UserProfile.findOne({userId: userId}).then(function(userProfile) {
            for (let index = 0; index < userProfile.userItemList.length; index++) {
                if(itemCode==userProfile.userItemList[index].itemCode){
                    userProfile.userItemList[index].rating = rating;
                }
            }
            userProfile.save();
            resolve(userProfile);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    });
};

userDB.addReadIt = function (itemCode, userId, readIt){
    return new Promise((resolve, reject) =>{
        UserProfile.findOne({userId: userId}).then(function(userProfile) {
            for (let index = 0; index < userProfile.userItemList.length; index++) {
                if(itemCode==userProfile.userItemList[index].itemCode){
                    userProfile.userItemList[index].readIt = readIt;
                }
            }
            userProfile.save();
            resolve(userProfile);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

userDB.deleteUserItem = function(itemCode, userId){
    return new Promise((resolve, reject) =>{
        UserProfile.findOne({userId: userId}).then(function(userProfile) {
            for (let index = 0; index < userProfile.userItemList.length; index++) {
                if(itemCode==userProfile.userItemList[index].itemCode){
                    userProfile.userItemList.splice(index, 1);
                }
            }
            userProfile.save();
            resolve(userProfile);
        }).catch(function(err) {
            console.log("Error:", err);
            return reject(err);
        });
    })
};

module.exports = userDB;





/*
var express = require('express');
var app = express();

//var ItemDBModel = require('./itemDB')
var userModel = require('../models/User');
var UserItem = require('../models/UserItem');
var UserProfile = require('../models/UserProfile');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/bookbarn',{ useNewUrlParser: true }, function(err){
  if(err) throw err;
  console.log("Database connected successfully!");
});

var userData = mongoose.Schema({
  userId:{type:String, required:true, unique:true},
  firstName:{type:String},
  lastName:{type:String},
  email:{type:String}
},{collection:'users'});

var userItemSchema = mongoose.Schema({
  userId:{type:String, required:true},
  item: {
    itemCode:{type:String, required:true},
    itemName:{type:String},
    catalogCategory:{type:String}
  },
  rating:{type:String},
  readIt:{type:Boolean}
},{collection:'userItem'});

//var user = mongoose.model('User', userData);
//var userItems = mongoose.model('userItem', userItemSchema);

module.exports.getUsers = async function(){
  var users = null;
  await user.find(function(err, data){
    if(err){
      throw err;
    }
    else{
      users = data[0];
    }
  });
  return users;
};

module.exports.getUser = async function(userId){
  var users = null;
  await user.find({'userId':userId, function(err, data){
    if (err) {
      throw err;
    }
    else{
      users = data;
    }
  }
  });
  return users;
}

module.exports.getUserProfile = async function(userId){
  if(userItems){
    return new userProfile(userId, await userItems.find({"userId": userId}));
  }
}

module.exports.removeItem = async function(userId, itemCode){
  if(userItems){
    var item =await userItems.find({'userId':userId, 'item.itemCode':itemCode}).remove();
  }
}

module.exports.addItem = async function(userId, usItem){
  if(userItems){
    var item = new userItems({
      'userId': userId,
      'item': {
        'itemCode': usItem.item[0].itemCode,
        'itemName': usItem.item[0].itemName,
        'catalogCategory': usItem.item[0].catalogCategory
      },
      'rating': usItem.rating,
      'readIt': usItem.readIt
    });
    await item.save(function(err){
      if(err){
        console.log(err);
      }
    });
  }
}

module.exports.updateItem = async function(userId, usItem){
  if(userItems){
    await userItems.update({'userId':userId, 'item.itemCode':usItem.item[0].itemCode},{'rating' :usItem.rating,'readIt' :usItem.readIt},function(err, data){
      if(err){
        console.log(err);
      }
    });
  }
}
*/
