var mongoose = require('mongoose');

var schemaOptions = {
    timestamps: true,
    toJSON: {
      virtuals: true
    }
};

var UserItemListSchema = new mongoose.Schema({
    itemCode: {
        type: Number,
        required: true
    },
    itemName: {
        type: String,
        required: true,
        trim: true,
    },
    catalogCategory: {
        type: String,
        required: true,
        trim: true,
    },
    rating: Number,
    readIt: Boolean
})

var UserProfileSchema = new mongoose.Schema({
    userId: {
        type: Number,
        required: true,
        trim: true,
        unique: true
    },
    userItemList: [UserItemListSchema]
}, schemaOptions);

module.exports = mongoose.model('users_profiles', UserProfileSchema);











/*var UserProfile = function(userId, userItems){

  this.userId = userId;
  this.userItems = userItems;

  this.addItem = function(userItems){
    this.userItems.push(userItems);
  };

  this.removeItem = function(itemCode){
    for(var i=0; i<this.userItems.length; i++){
      if(itemCode == this.userItems[i].item.itemCode){
        this.userItems.splice(i,1);
        break;
      }
    }
  };

  this.updateItem = function(userItems){
    for(var i = 0; i<this.userItems.length; i++){
      if(userItems.item.itemCode == this.userItems[i].item.itemCode){
        this.userItems[i].item = userItems.item;
        this.userItems[i].rating = userItems.rating;
        this.userItems[i].readIt = userItems.readIt;
      }
    }
  };

  this.getItems = function(){
    return this.userItems;
  };

  this.emptyProfile = function(){
    this.user = null;
    this.userItems = null;
  };
}






/*
var UserItem = require('./UserItem');

class UserProfile {

    /**
     * Constructor
     * @param userId
     * @param userItemList

    constructor(userId) {
        this._userId = userId;
        this._userItemList = [];
    }

    /**
     *
     * Getter and Setters


    get userId() {
        return this._userId;
    }

    set userId(value){
        this._userId = value;
    }

    get userItemList(){
        return this._userItemList;
    }

    set userItemList(value){
        this._userItemList = value;
    }

    addItem(userItem){
        if(userItem instanceof UserItem){
            this._userItemList.push(userItem);
        }else{
            console.log('Invalid Object --> It should be of type UserItem')
        }
    }

    removeItem(userItem){
        if(userItem instanceof UserItem){
          this._userItemList.filter(function(item){
            return item!=userItem;
          });
        }
        else{
            console.log('Invalid type of object')
        }
    }

    updateItem(userItem){
        if(userItem instanceof UserItem){
          const index = this._userItemList.findIndex((e) => e.item.itemCode === userItem.item.itemCode);
          if (index === -1){
            console.log('User Item not present in the list');
          }
          else{
            this._userItemList[index] = userItem;
          }
        }
        else{
          console.log('Invalid type of object')
        }
    }

    getItems(){
        return this._userItemList;
    }

    emptyProfile(){
        this.userItemList = [];
    }

}
*/

//module.exports = UserProfile;
