class UserItem {


    constructor(itemCode, itemName, catalogCategory, rating, readIt) {
        this._itemCode = itemCode;
        this._itemName = itemName;
        this._catalogCategory = catalogCategory;
        this._rating = rating;
        this._readIt = readIt;
    }

    get itemCode() {
        return this._itemCode;
    }

    set itemCode(value){
        this._itemCode = value;
    }

    get itemName() {
        return this._itemName;
    }

    set itemName(value){
        this._itemName = value;
    }

    get catalogCategory() {
        return this._catalogCategory;
    }

    set catalogCategory(value){
        this._catalogCategory = value;
    }

    get rating(){
        return this._rating;
    }

    set rating(value){
        this._rating = value;
    }

    get readIt(){
        return this._readIt;
    }

    set readIt(value){
        this._readIt = value;
    }

}
module.exports = UserItem;













/*var UserItem = function(item,rating,readIt,saved){

  userItemModel = {
    item : item,
    rating : rating,
    readIt : readIt,
    saved: saved
  }
  return userItemModel;
}

UserItem.prototype.getItem = function(){
  return this.item;
}
UserItem.prototype.getRating = function(){
  return this.rating;
}
UserItem.prototype.getReadIt = function(){
  return this.readIt;
}
UserItem.prototype.getSaved = function(){
  return this.saved;
}

UserItem.prototype.setItem = function(item){
  this.item = item;
}
UserItem.prototype.setRating = function(rating){
  this.rating = rating;
}
UserItem.prototype.setReadIt = function(readIt){
  this.readIt = readIt;
}
UserItem.prototype.setSaved = function(saved){
  this.saved = saved;
}

/*class UserItem {

    /**
     * Constructor
     * @param itemCode
     * @param itemName
     * @param catalogCategory
     * @param rating
     * @param madeIt

    constructor(itemCode, itemName, catalogCategory, rating, readIt) {
        this._itemCode = itemCode;
        this._itemName = itemName;
        this._catalogCategory = catalogCategory;
        this._rating = rating;
        this._readIt = readIt;
    }


     *
     * Getter and Setters

    get itemCode() {
        return this._itemCode;
    }

    set itemCode(value){
        this._itemCode = value;
    }

    get itemName() {
        return this._itemName;
    }

    set itemName(value){
        this._itemName = value;
    }

    get catalogCategory() {
        return this._catalogCategory;
    }

    set catalogCategory(value){
        this._catalogCategory = value;
    }

    get rating(){
        return this._rating;
    }

    set rating(value){
        this._rating = value;
    }

    get readIt(){
        return this._readIt;
    }

    set readIt(value){
        this._readIt = value;
    }

}
*/
//module.exports = UserItem;
