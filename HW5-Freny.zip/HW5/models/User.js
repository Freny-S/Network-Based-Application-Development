var mongoose = require('mongoose');

var UserSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        trim: true
    },
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        trim: true
    },
    username: {
      type: String,
      trim: true
    },
    password: {
      type: String,
      required: true  
    }
});


module.exports = mongoose.model('user', UserSchema);


/*var User = function(userId,firstName,lastName,email){
  userModel = {
    userId : userId,
    firstName : firstName,
    lastName : lastName,
    email : email
  }
  return userModel;
}

/*
class User {

    /**
     * Constructor
     * @param userId
     * @param firstName
     * @param lastName
     * @param email

    constructor(userId, firstName, lastName, email) {
        this._userId = userId;
        this._firstName = firstName;
        this._lastName = lastName;
        this._email = email;
    }

    /**
     *
     * Getter and Setters


    get userId() {
        return this._userId;
    }

    set userId(value){
        this._userId = value;
    }

    get firstName(){
        return this._firstName;
    }

    set firstName(value){
        this._firstName = value;
    }

    get lastName(){
        return this._lastName;
    }

    set lastName(value){
        this._lastName = value;
    }

    get email(){
        return this._email;
    }

    set email(value){
        this._email = value;
    }

}
*/
