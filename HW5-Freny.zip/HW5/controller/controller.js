var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var session = require('express-session');
var itemDb = require('../utility/ItemDB.js');
var User = require('../utility/UserDB.js');
var UserItem = require('../models/UserItem.js');
var UserProfile = require('../models/UserProfile.js');
var profilecontroller = require('./ProfileController');
var urlencodedParser = bodyParser.urlencoded({
  extended: false
});
//router.use(profileController);
router.use(bodyParser.json());

router.use(bodyParser.urlencoded({extended: false}));

var user = null;
var userProfile = null;
router.use(function getSession(req,res,next){
    if(req.session.theUser){
        user = req.session.theUser;
        userProfile = req.session.userProfile;
    }else{
        user = null;
        userProfile = null;
    }
    next();
});

router.all('/', function(req, res){
    var data = {
        title: 'Index',
        path: req.url,
        user: user
    };
    res.render('index',{data: data});
});

router.get('/signin',async function(req, res){
  var data ={
    user: {},
    userProfile: {}
  }
  res.render('login', {data: data});
    // if(req.session.theUser){
    //     res.redirect('/login');
    // }else{
    //     var users =await  User.getUsers();
    //     var user = users[Math.floor(Math.random()*users.length)];
    //     req.session.theUser = user;
    //     req.session.userProfile = await User.getUserProfile(user.userId);
    //     res.redirect('/login');
    // }
});

router.get('/signout', function(req, res){
    if(req.session.theUser){
        req.session.theUser = null;
        res.redirect('/');
    }
});

router.get('/myBooks', async function(req, res){
  var user = req.session.theUser;
  var userProfile = await User.getUserProfile(req.session.theUser.userId);
  if(!req.session.theUser){
    var data= {
        title:'Login',
        path: req.url,
        user: user
    };
    res.redirect('/signin');
  }
  else{
    var userProfile = await User.getUserProfile(req.session.theUser.userId);
    var user = req.session.theUser;
    var data= {
      path: req.url,
      user: user,
      userProfile: userProfile
    }
    res.render('myBooks', {data: data});
  }
    // if (req.session.theUser) {
    //     var data = {
    //         title: 'myBooks',
    //         path: req.url,
    //         user: user,
    //         userProfile: userProfile
    //     };
    //     res.render('myBooks', {
    //         data: data
    //     });
    // } else {
    //     var users = await User.getUsers();
    //     var user1 = users[Math.floor(Math.random() * users.length)];
    //     req.session.theUser = user1;
    //    // req.session.userProfile = userDB.getUserProfile(user1.userId);
    //     res.redirect('/myBooks');
    // }
});

router.get('/login', function(req, res) {
    var data= {
        title:'Login',
        path: req.url,
        user: user
    };
    res.render('login',{data: data});
});

router.post('/authUser', urlencodedParser, async function(req, res){
  var data= {
      path: req.url,
      user: user
  };
  req.check('username').isLength({
    min: 3
  }).withMessage('Username must be at least 3 characters long');
  req.checkBody('password')
    .matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#%&])[0-9a-zA-Z!@#%&]{6,}$/).withMessage('Password must contain a number, a special character (allowed special characters are @!#%&), a lowercase and an uppercase letter. Password must be at least 6 characters long.')
  var errors = req.validationErrors();
  //console.log("Error " + req.body.password + " " + JSON.stringify(errors));
  if (errors) {
    res.render('login', {
      user: {},
      userProfile: {},
      errorMsg: errors
    });
  } else {
    var user = await User.getUser(req.body.username, req.body.password);
    var itemData = await itemDb.getItems();
    //console.log("user " + user);
    if (user) {
      req.session.userProfile = await User.getUserProfile(user.userId);
      req.session.theUser = user;
      res.render('myBooks', {
        data: data
      });
    } else {
      var errors = [{
        msg: "Username or Password does not match."
      }];
      res.render('login', {
        user: {},
        userProfile: {},
        errorMsg: errors
      });
    }
  }
});


router.get('/categories',async function(req, res) {
    var itemData = await itemDb.getItems();
    var categories =await  itemDb.getCategories();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData,
        user: user
    };

    res.render('categories',{data: data});
});

router.get('/contact', function(req, res) {
    var data= {
        title:'Contact',
        path: req.url,
        user: user
    };
    res.render('contact',{data: data});
});

router.get('/about', function(req, res) {
    var data= {
        title:'About',
        path: req.url,
        user: user
    };
    res.render('about',{data: data});
});



router.get('/categories/item/:itemCode',async function(req, res) {

        var itemData = await itemDb.getItem(req.params.itemCode);
      //  //console.log("********************************" + itemData.imageURL);
        var index = -1;
        if(req.session.userProfile){
            index = profilecontroller.getSelectedItem(req.session.userProfile.userItemList, req.params.itemCode);
        }
        var data= {
            title:'Item',
            path: req.url,
            item: itemData,
            user: user,
            userProfile: userProfile,
            index: index
        };
        res.render('item',{data: data});

});

router.get('/categories/item/saveIt/:itemCode',async function (req, res) {
    var index = -1;
    if (req.session.theUser) {
        index = getSelectedItem(req.session.userProfile.userItemList, req.params.itemCode);
        if (index == -2) {
            var itemData = await itemDb.getItem(req.params.itemCode);
            var userItem = {
                itemCode: itemData.itemCode,
                itemName: itemData.itemName,
                catalogCategory: itemData.catalogCategory,
                rating: 0,
                readIt: false
            };
            var userProfile = await User.addUserItem(req.session.theUser.userId,userItem);
            req.session.userProfile = userProfile;
            console.log('session userprofile', req.session.userProfile);
            res.redirect('/myBooks');
        } else {
            console.log('Item already present');
            res.redirect('/myBooks');
        }
    } else {
        res.redirect('/categories/item/' + req.params.itemCode);
    }
});


router.post('/update/feedback/:itemCode',async function (req, res) {
  var itemCode = req.params.itemCode;
  if (req.session.theUser) {
  //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$" + req.body.rating);
  var userProfile = await User.addItemRating(itemCode, req.session.theUser.userId, parseInt(req.body.rating));
   req.session.userProfile = userProfile;
   res.redirect('/myBooks');
 }
});


router.post('/update/readIt/:itemCode',async function (req, res) {
  var itemCode = req.params.itemCode;
  if (req.session.theUser) {
  //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$" + req.body.rating);
  var userProfile = await User.addReadIt(itemCode, req.session.theUser.userId,true);
   req.session.userProfile = userProfile;
   res.redirect('/myBooks');
 }
});

router.get('/categories/item/feedback/:itemCode',async function(req, res) {
  if (req.session.theUser){
    console.log("IN CONSOLE");
    var itemData = await itemDb.getItem(req.params.itemCode);
    var data= {
        title:'Feedback',
        path: req.url,
        item: itemData,
        user: user
    };
    res.render('feedback',{data: data});
  }
});
router.get('/myBooks/delete/:itemCode',async function(req, res){
    if(req.session.theUser){
            var userProfile = await User.deleteUserItem(req.params.itemCode,req.session.theUser.userId);
            req.session.userProfile = userProfile;
            res.redirect('/myBooks');

    }else{
        res.redirect('/');
    }
});



var getSelectedItem = function (itemList, itemCode) {
    for (var index = 0; index < itemList.length; index++) {
        if (itemList[index].itemCode == parseInt(itemCode, 10)) {
            return index;
        }
    }
    return -2;
};



router.get('/*',function(req,res){
    var data= {
        title:'Error',
        path: req.url
    };
    //console.log('404')
    res.render('error',{data: data});
});
module.exports = router;
