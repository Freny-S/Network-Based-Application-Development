var express = require('express');
var app = express();
var router = express.Router();
var itemDb = require('../utility/ItemDB.js');
var userDB = require('../utility/UserDB.js');
var userItemModel = require('../models/UserItem.js');
var userProfileModel = require('../models/UserProfile.js');
var session = require('express-session');
var bodyParser = require('body-parser');
//var confirm = require('confirm-dialog');
var querystring = require('querystring');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended: false}));

app.set('view engine','ejs');
app.use('/assets', express.static('assets'));

// router.post('/signin',async function(req, res){
//   var errorMessage = req.session.errorMessage;
//   req.session.errorMessage = null;
//     if(req.session.theUser){
//         res.redirect('/');
//     }else{
//         var users =await  userDB.getUsers();
//         var user = users[Math.floor(Math.random()*users.length)];
//         req.session.theUser = user;
//         req.session.userProfile = await userDB.getUserProfile(user.userId);
//         console.log("----------------------------$$$$$$$44 " + req.session.theUser);
//         res.redirect('/myBooks');
//     }
// });

// router.post('/signout', function(req, res){
//     if(req.session.theUser){
//         req.session.theUser = null;
//         res.redirect('/');
//     }
// });


// router.get('/categories/item/saveIt/:itemCode',async function (req, res) {
//     var index = -1;
//     if (req.session.theUser) {
//         index = getSelectedItem(req.session.userProfile.userItemList, req.params.itemCode);
//         if (index == -2) {
//             var itemData = await itemDb.getItem(req.params.itemCode);
//             var userItem = {
//                 itemCode: itemData.itemCode,
//                 itemName: itemData.itemName,
//                 catalogCategory: itemData.catalogCategory,
//                 rating: 0,
//                 readIt: false
//             };
//             var userProfile = await userDB.addUserItem(req.session.theUser.userId,userItem);
//             req.session.userProfile = userProfile;
//             console.log('session userprofile', req.session.userProfile);
//             res.redirect('/myBooks');
//         } else {
//             console.log('Item already present');
//             res.redirect('/myBooks');
//         }
//     } else {
//         res.redirect('/categories/item/' + req.params.itemCode);
//     }
// });

/*
router.get('/categories/item/feedback/:itemCode',async function (req, res) {
    var index = -1;
    var itemCode = -1;
    if(req.body.itemCode == req.body.itemList){
        itemCode = req.body.itemCode;
        if (req.session.theUser) {
            index = getSelectedItem(req.session.userProfile.userItemList, itemCode);
            if (index == -2) {

                res.redirect('/myBooks');
            } else {
                if (req.body.feedbackHidden == 'rating') {
                    console.log(req.body.rating);
                     var userProfile = await userDB.addItemRating(itemCode, req.session.theUser.userId, parseInt(req.body.rating, 10));
                    req.session.userProfile = userProfile;
                    res.redirect('/myBooks');
                } else if (req.body.feedbackHidden == 'readIt') {
                    console.log(req.body.readItRadio);
                    if(req.body.readItRadio != 'undefined'){
                          var userProfile = await userDB.addReadIt(itemCode, req.session.theUser.userId, JSON.parse(req.body.readItRadio));
                            req.session.userProfile = userProfile;
                          res.redirect('/myBooks');
                    }
                    var userProfile = await userDB.addReadIt(itemCode, req.session.theUser.userId, JSON.parse(req.body.readItRadio));
                    req.session.userProfile = userProfile;
                    res.redirect('/myBooks');
                } else {
                    console.log('Incorrect paramter');
                    res.redirect('/categories/item/' + req.params.itemCode + '/feedback');
                }
            }
        } else {
            res.redirect('/categories/item/' + req.params.itemCode + '/feedback');
        }
    }else{
        res.redirect('/categories/item/' + req.params.itemCode + '/feedback');
    }
});
*/

// app.post('/', urlencodedParser, async function(req, res){
//   if(JSON.stringify(user) != JSON.stringify({})){
//     if(itemList.length <= 1){
//       if(req.)
//     }
//   }
// }

var getSelectedItem = function (itemList, itemCode) {
    for (var index = 0; index < itemList.length; index++) {
        if (itemList[index].itemCode == parseInt(itemCode, 10)) {
            return index;
        }
    }
    return -2;
};

module.exports.getSelectedItem = getSelectedItem;

module.exports.router = router;


























/*
app.get('/myBooks',async function(req,res){

  try{

    //check if session variable is set or not
    var theUser = req.session.theUser;
    if( theUser == undefined){
      var user = await userDBModel.getUsers();
      if(user == null){
        res.render('noData');
      }
      req.session.theUser = user;
      req.session.currentUserProfile = await userDBModel.getUserProfile(user.userId);
      var currentUserProfile = req.session.currentUserProfile;
      if(req.session.currentUserProfile.length == 0){
        res.render('noData');
      }
      req.session.success = true;
      res.render('myBooks', {
          success: true,
          userId: req.session.theUser.userId,
          userItems: currentUserProfile.userItems,
          username : user.firstName + " " + user.lastName
      });

    }
    //session variable to not null
      else if(theUser != null || theUser != undefined){
        var user = req.session.theUser;
        req.session.currentUserProfile =await userDBModel.getUserProfile(user.userId);
        var currentUserProfile = req.session.currentUserProfile;
        var action = req.query.action;
    //if no action is given then redirect to myItems page
        if(action == undefined){
          res.render('myBooks',{
            success:true,
            userId: user.userId,
            username: user.firstName + " " + user.lastName,
            userItems: currentUserProfile.userItems
          });
        }
    //when action is "Delete"
        else if(action == "delete"){
          var itemCode = req.query.itemCode;
          console.log("In delete action : ",itemCode);

          // confirm('DO YOU WANT TO DELETE THE ITEM?').then(function() {
          //   // yes
          //   //use actions present in userProfile to perform delete action
          //   req.session.currentUserProfile.removeItem(itemCode);
          // }, function() {
          //   // no
          // })
          //req.session.currentUserProfile.removeItem(itemCode);
          await userDBModel.removeItem(user.userId,itemCode);
          res.redirect('/myBooks');
        }
    //When action is "Save"
        else if(action == "save"){
          var itemCode = req.query.itemCode;
          console.log("In SAVE action : ",itemCode);
          var itemPresent = false;
          //check if already present!!
          for(var i=0; i< req.session.currentUserProfile.userItems.length; i++){
            if(req.session.currentUserProfile.userItems[i].item.itemCode === itemCode){
              //alert that the item already present!!
              console.log("item already present!!");
              itemPresent= true;
            }
          }
          //If item not present
          if(!itemPresent){
            var item =await itemDBModel.getItem(itemCode);
            var userItem =await userItemModel.userItem(item,item[0].rating,"No");
            //use actions present in userProfile to perform delete action
            await userDBModel.addItem(user.userId, userItem);
          }
          res.redirect('/myBooks');
          }

      }


  }
  catch(err){
    console.log("in items error: ");
    console.log(err);
  }

  });








/*
var express = require('express');
var router = express.Router();
var userDB = require('../utility/UserDB');
var itemDb = require('../utility/ItemDB');
var bodyParser = require('body-parser');
var session = require('express-session');
var User = require('../models/User');
var UserProfile = require('../models/UserProfile');
var UserItem = require('../models/UserItem');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended:false }));
router.use(session({secret: 'freny_session'}));

router.get('/signin', function(req, res, next){
    //console.log("Hey");
    if(req.session.theUser){
        //console.log('Already logged in');
        res.redirect('/myBooks');
    }
    else{
        //console.log("signin");
        users = userDB.getUsers();
        var user = users[Math.floor(Math.random() * users.length)];
        req.session.theUser = user;
        req.session.userProfile = userDB.getUserProfile(user.userId);
        res.redirect('/myBooks');
    }
});

router.get('/signout', function(req, res, next){
    if(req.session.theUser){
        req.session.theUser = null;
        res.redirect('/');
    }
});

router.get('/categories/item/saveIt/:itemCode', function(req, res, next){
    if(req.session.theUser){
      //console.log("yo");
      var itemCode = req.params.itemCode;
      //console.log("Item Code:"+itemCode);
      var item = itemDb.getItem(itemCode);
      var userItem = new UserItem(item.itemCode, item.itemName, item.catalogCategory, 0, false);
        req.session.userProfile._userItemList.push(userItem);
        //console.log('userProfile - save : ',req.session.userProfile._userItemList);
        res.redirect('/myBooks');
    }
    else{
        res.redirect('/categories/item/' + req.params.itemCode);
    }
});

router.post('/update/feedback/:itemCode', function(req, res){
    var temp=-1;
    if(req.session.theUser){
        temp = getSelectedItem(req.session.userProfile._userItemList, req.params.itemCode);
        if(temp==-2){
            res.redirect('/myItems');
        }else{
            if(req.body.feedbackHidden=='rating'){
                req.session.userProfile._userItemList[temp]._rating = parseInt(req.body.rating,10);
                res.redirect('/myBooks');
            }else if(req.body.feedbackHidden=='readIt'){
                req.session.userProfile._userItemList[temp]._madeIt = JSON.parse(req.body.readItRadio);
                res.redirect('/myBooks');
            }else{
                res.redirect('/categories/item/'+req.params.itemCode+'/feedback');
            }
        }
    }else{
        res.redirect('/categories/item/'+req.params.itemCode+'/feedback');
    }
});

function getSelectedItem(itemList, itemCode){
    for (var index = 0; index < itemList.length; index++) {
        //console.log(itemList[index]._itemCode);
        //console.log(itemList[index]._itemCode == parseInt(itemCode,10));
        if(itemList[index]._itemCode == parseInt(itemCode,10)){
            return index;
        }
    }
    return -2;
}

router.get('/myBooks/delete/:itemCode', function(req, res){
    var index = -1;
    if(req.session.theUser){
        index = getSelectedItem(req.session.userProfile._userItemList, req.params.itemCode);
        if(index==-2){
            //console.log('Item not present in the user profile');
            res.redirect('/myBooks');
        }else{
            req.session.userProfile._userItemList.splice(index, 1);
            res.redirect('/myBooks');
        }
    }else{
        res.redirect('/myBooks');
    }
});
*/
