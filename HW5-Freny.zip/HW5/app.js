var express = require('express');
var app = express();
//var router = express.Router();
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

mongoose.connect('mongodb://localhost/bookbarn',{
  useNewUrlParser: true
}).then(() =>  console.log('connection successful'))
  .catch((err) => console.error(err));

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

var bodyParser = require('body-parser');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var expressValidator = require('express-validator');
app.use(expressValidator());


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:false }));
app.use(session({
  secret: 'freny_session',
  resave: true,
  saveUninitialized: true,
  cookie: {
    maxAge: 1000 * 30 * 60
  }
}));

var User = require('./utility/UserDB.js');

var controller = require('./controller/controller.js');
var profilecontroller = require('./controller/ProfileController.js');

var userProfile = {};
var user = {};

//app.use('/', profilecontroller.router);
app.use('/', controller);
//app.use('/ProfileController', profilecontroller);
/*
app.use('/categories',controller);
app.use('/about',controller);
app.use('/contactUs',controller);
app.use('/categories/item/:id',controller);
app.use('/*',controller);
*/

app.use(function getSession(req,res,next){
    if(req.session.theUser){
        user = req.session.theUser;
        userProfile = req.session.userProfile;
    }else{
        user = null;
        userProfile = null;
    }
    next();
});

app.listen('8080', function(req, res){
  console.log("Server started. Listening on port 8080");
});
