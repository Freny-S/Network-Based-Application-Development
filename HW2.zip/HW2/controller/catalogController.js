var express = require('express');
var router = express.Router();
var itemDb = require('../models/itemDB');

router.get('/', function(req, res, next) {
    var page= {
        title:'Home',
        path: req.url
    }

  res.render('index');
});

router.get('/categories', function(req, res, next) {
    var categories = getCategories();
    var itemData = itemDb.getItems();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData
    }
    console.log(itemData);
    res.render('categories',{ data: data});
});

router.get('/categories/:categoryName', function (req,res) {
    // get the category name
    var categories = [];
    categories.push(req.params.categoryName);
    var itemData = itemDb.getItems();
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: itemData
    }
    res.render('categories',{ data: data});
});

router.get('/contact', function(req, res, next) {
    var page= {
        title:'Contact Us',
        path: req.url
    }

    res.render('contact');
});
router.get('/about', function(req, res, next) {
    var page= {
        title:'About Us',
        path: req.url
    }

    res.render('about');
});
router.get('/categories/item/:itemCode', function(req, res, next) {
    var itemCode = req.params.itemCode;
    console.log("Item Code:"+itemCode);
    var item = itemDb.getItem(itemCode);
    console.log(item);
    var data= {
        title:'Item',
        path: req.url,
        item: item
    }

    res.render('item',{ data: data});
});
router.get('/myBooks', function(req, res, next) {
    var page= {
        title:'My Books',
        path: req.url
    }

    res.render('myBooks');
});
var categories = [];
let getCategories = function() {
    // get the category of each item
    var data = itemDb.getItems();
    data.forEach(function (item) {
        if(!categories.includes(item.catalogCategory)){
            categories.push(item.catalogCategory);
        }

    });
    return categories;
};

router.get('/feedback', function(req, res, next) {
    var page= {
        title:'Feedback',
        path: req.url
    }
    res.render('feedback', {title:page});
});

module.exports = router;
