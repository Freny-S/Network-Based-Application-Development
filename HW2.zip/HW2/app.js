var express = require('express');

var app = express();

app.set('view engine', 'ejs');
app.use('/public', express.static('public'));

var catalogController = require('./controller/catalogController');

app.use('/', catalogController);
app.use('/myBooks', catalogController);
app.use('/categories',catalogController);
app.use('/categories/:categoryName',catalogController);
app.use('/categories/item/:itemCode',catalogController);
app.use('/contact', catalogController);
app.use('/about', catalogController);
app.use('/feedback', catalogController);


app.listen(3000);
