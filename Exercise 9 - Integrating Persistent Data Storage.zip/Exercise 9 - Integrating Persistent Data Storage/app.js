/* @nanajjar */

//setup express to use for routing
var express = require('express');
var app = express();
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Students',{ useNewUrlParser: true });
var TodoSchema = mongoose.Schema;

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
  console.log("Database Connected Successfully!");
});

var schemaOptions = {
    timestamps: true,
    toJSON: {
      virtuals: true
    }
};

var studentSchema = new TodoSchema({
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  },
  degree: String,
  program: String
}, schemaOptions);

var Student = mongoose.model('Student', studentSchema);


app.set('view engine', 'ejs');

app.use('/resources', express.static('resources'));

var studentInfo = require('./controls/studentInfo.js');
var index = require('./controls/index.js');
var bodyParser = require('body-parser');
var session = require('express-session');

var urlencodedParser = bodyParser.urlencoded({ extended:false });

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended:false }));

app.use(session({secret: 'session'}));

app.use('/', index);

app.use('/studentInfo',studentInfo);

var counter = 0;

app.post('/studentInfo', function(req,res,next){
  console.log(req.body);
  var theStudent = require('./models/student');
  if(req.body.firstName=='' || req.body.lastName=='' || req.body.degree=='' || req.body.program==''){
    res.redirect('/');
  }
  theStudent.setFirstName(req.body.firstName);
  theStudent.setLastName(req.body.lastName);
  theStudent.setDegree(req.body.degree);
  theStudent.setProgram(req.body.program);
  var student = theStudent.getStudentInfo();
  if(db.readyState==1){
    Student.findOneAndUpdate({firstName:req.body.firstName,lastName: req.body.lastName}, student, {new: true, upsert: true, setDefaultsOnInsert: true}, function(error, result) {
      if(error){
        console.log("Something went wrong, try again!");
        return handleError(error);
      }
      console.log(result);
      console.log('Data Saved!');
      req.session.theStudent = theStudent.getStudentInfo();
      if(req.session.theStudent){
        student = req.session.theStudent;
        res.render('main', { student: student });
      }else{
        res.redirect('/');
      }
    });
  }else{
    console.log('Connection not established, try again!');
  }
});

app.get('/display',function(req,res){
  console.log(mongoose.connection.readyState);
  if(db.readyState==1){
    Student.find(function (err, students) {
      if (err) return console.error(err);
      console.log(students);
      res.render('display',{students:students});
    });
  }else{
    console.log('Connection not established, try again!');
  }
});

app.post('/search', function(req,res){
  var firstName = req.body.firstName;
  if(db.readyState==1){
    Student.find({firstName: firstName},function(err, students){
      if (err) return console.error(err);
      console.log(students);
      res.render('display',{students:students});
    });
  }else{
    console.log('Connection not established, try again!');
  }
});

app.listen(8080, '127.0.0.1');
